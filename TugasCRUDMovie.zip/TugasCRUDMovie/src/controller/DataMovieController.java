/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DataMovieDAO.DataMovieDAO;
import DataMovieInterface.DataMovieInterface;
import javax.swing.JOptionPane;
import model.*;
import View.MainView;
/**
 *
 * @author jovan
 */
public class DataMovieController {
    MainView frame;
    DataMovieInterface ImplDataMovie;
    List<DataMovie> dm;

    public DataMovieController(MainView frame) {
        this.frame = frame;
        ImplDataMovie = new DataMovieDAO();
        dm = ImplDataMovie.getAll();
    }

    public void isiTabel() {
        dm = ImplDataMovie.getAll();
        ModelTabelDataMovie mm = new ModelTabelDataMovie(dm);
        frame.gettbl_data().setModel(mm);
    }

    public void insert() {
        DataMovie dm = new DataMovie();
        dm.setJudul(frame.gett_Judul().getText());
        dm.setAlur(Double.parseDouble(frame.gett_Alur().getText()));
        dm.setPenokohan(Double.parseDouble(frame.gett_Penokohan().getText()));
        dm.setAkting(Double.parseDouble(frame.gett_Akting().getText()));
        dm.setNilai(dm.getNilai());
        ImplDataMovie.insert(dm);
    }

    public void update() {
        DataMovie dm = new DataMovie();
        dm.setJudul(frame.gett_Judul().getText());
        dm.setAlur(Double.parseDouble(frame.gett_Alur().getText()));
        dm.setPenokohan(Double.parseDouble(frame.gett_Penokohan().getText()));
        dm.setAkting(Double.parseDouble(frame.gett_Akting().getText()));
        dm.setNilai(dm.getNilai());
        ImplDataMovie.update(dm);
    }

    public void delete() {
        String judul = frame.gett_Judul().getText();
        ImplDataMovie.delete(judul);
    }
}
